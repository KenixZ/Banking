import java.util.HashMap;

import java.util.Map;

public class Bank {
    private Map<String, Account> accounts;

    Bank() {
        accounts = new HashMap<>();
    }

    public Map<String, Account> getAccounts() {
        return accounts;
    }

    public void addAccount(Account accountToBeAdded) {
        accounts.put(accountToBeAdded.getID(), accountToBeAdded);
    }

    public void deposit(String accountID, double amount) {
        accounts.get(accountID).deposit(amount);
    }

    public void withdraw(String accountID, double amount) {
        accounts.get(accountID).withdraw(amount);
    }
}
