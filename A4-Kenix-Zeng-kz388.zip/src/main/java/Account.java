public abstract class Account {
    private String id;
    private double amount;
    private double apr;

    public Account(String id, double apr, double amount) {
        this.amount = amount;
        this.apr = apr;
        this.id = id;
    }

    public double getAmount() {
        return amount;
    }

    public double getAPR() {
        return apr;
    }

    public String getID() {
        return id;
    }

    public void deposit(double depositAmount) {
        if (depositAmount > 0) {
            amount += depositAmount;
        }
    }

    public void withdraw(double withdrawAmount) {
        if (withdrawAmount > 0) {
            if (amount <= withdrawAmount) {
                amount = 0;
            } else {
                amount -= withdrawAmount;
            }
        }
    }
}
