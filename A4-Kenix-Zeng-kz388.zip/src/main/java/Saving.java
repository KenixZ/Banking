public class Saving extends Account{

    public Saving(String id, double apr) {
        super(id, apr,0);
    }
}
