import org.junit.jupiter.api.BeforeEach;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class BankTest {

    public static final String checkingAccountID = "10000000";
    public static final String savingAccountID = "20000000";
    public static final String cdAccountID = "30000000";

    public static final int checkingAccountAPR = 1;
    public static final int savingAccountAPR = 2;
    public static final int cdAccountAPR = 3;

    Bank bank;
    Checking checkingAccount;
    Saving savingAccount;
    CD cdAccount;

    @BeforeEach
    void setUp() {
        bank = new Bank();
        checkingAccount = new Checking(checkingAccountID, checkingAccountAPR);
        savingAccount = new Saving(savingAccountID, savingAccountAPR);
        cdAccount = new CD(cdAccountID, cdAccountAPR,100);
    }

    @Test
    void bank_created_and_has_no_accounts() {
        assertTrue(bank.getAccounts().isEmpty());
    }

    @Test
    void add_account_to_bank() {
        bank.addAccount(checkingAccount);
        assertEquals(checkingAccountID,bank.getAccounts().get(checkingAccountID).getID());
    }

    @Test
    void add_two_accounts_to_bank() {
        bank.addAccount(checkingAccount);
        assertEquals(checkingAccountID,bank.getAccounts().get(checkingAccountID).getID());
        bank.addAccount(savingAccount);
        assertEquals(savingAccountID,bank.getAccounts().get(savingAccountID).getID());
    }

    @Test
    void retrieve_correct_account_from_bank() {
        bank.addAccount(checkingAccount);
        bank.addAccount(savingAccount);
        assertEquals(checkingAccountID,bank.getAccounts().get(checkingAccountID).getID());
    }

    @Test
    void deposit_money_by_id_through_the_bank_with_correct_account_receiving_money() {
        bank.addAccount(checkingAccount);
        bank.deposit(checkingAccountID, 100);
        assertEquals(100,bank.getAccounts().get(checkingAccountID).getAmount());
    }

    @Test
    void withdraw_money_by_id_through_the_bank_with_correct_account_withdrawing_money() {
        bank.addAccount(checkingAccount);
        bank.deposit(checkingAccountID, 1000);
        bank.withdraw(checkingAccountID, 500);
        assertEquals(500,bank.getAccounts().get(checkingAccountID).getAmount());
    }

    @Test
    void depositing_twice_through_bank_works_as_expected() {
        bank.addAccount(checkingAccount);
        bank.deposit(checkingAccountID, 100);
        bank.deposit(checkingAccountID, 100);
        assertEquals(200,bank.getAccounts().get(checkingAccountID).getAmount());
    }

    @Test
    void withdrawing_twice_through_bank_works_as_expected() {
        bank.addAccount(checkingAccount);
        bank.deposit(checkingAccountID, 1000);
        bank.withdraw(checkingAccountID, 100);
        bank.withdraw(checkingAccountID, 100);
        assertEquals(800,bank.getAccounts().get(checkingAccountID).getAmount());
    }
}
